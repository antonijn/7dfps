#!/bin/sh
mono 7DFPS.exe
